
public class Board
{
//Some stuff will go in here.
}
