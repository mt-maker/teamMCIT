
public class Board
{
//Some stuff will go in here.
//Some more code here..  And here.
	//Other  stuff and change 2
}
